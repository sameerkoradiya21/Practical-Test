jQuery(document).ready(function () {
    jQuery('.toggle-bar').click(function () {
        jQuery(this).toggleClass('open');
    });


    // jQuery('.work-slider').owlCarousel({
    //     loop:true,
    //     margin:30,
    //     nav:false,
    //     dots:true,
    //     responsive:{
    //         0:{
    //             items:1
    //         },
    //         767:{
    //             items:2
    //         },
    //         1000:{
    //             items:3
    //         }
    //     }
    // });


    jQuery('.work-slider').slick({
        slidesToShow: 3,
        slidesToScroll: 1,        
        dots: true,
        responsive: [
            {
              breakpoint: 1024,
              settings: {
                slidesToShow: 2,
                slidesToScroll: 2,
                adaptiveHeight: true,
              },
            },
            {
              breakpoint: 480,
              settings: {
                slidesToShow: 1,
                slidesToScroll: 1,
              },
            },
          ],
    });

    jQuery('.testimonial-slider').slick({
        slidesToShow: 1,
        slidesToScroll: 1,        
        dots: true,
                      
    });

    // jQuery('.testimonial-slider').owlCarousel({
    //     loop:true,
    //     margin:30,
    //     nav:false,
    //     dots:true,        
    //     responsive:{
    //         0:{
    //             items:1
    //         }            
    //     }
    // })

    jQuery('.counter').counterUp({
          
    });
       
});

jQuery(window).scroll(function () {
    if ($(this).scrollTop() > 90) {
        jQuery('.header').addClass('fixed');
    } else {
        jQuery('.header').removeClass('fixed');
    }
});


